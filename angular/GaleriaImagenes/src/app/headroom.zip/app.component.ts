import { Component } from '@angular/core';

declare var Headroom;

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  ngAfterViewInit() {
    var myElement = document.querySelector("#header");
    // construct an instance of Headroom, passing the element
    var headroom = new Headroom(myElement, {
      offset: 0,
      tolerance: {
        up: 0,
        down: 0
      },
      classes: {
        initial: "header--fixed",
        pinned: "slideDown",
        unpinned: "slideUp",
        top: "top",
        notTop: "not-top"
      }
    });
    // initialise
    headroom.init();
  }

}
